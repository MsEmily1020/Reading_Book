package project;

public class Order extends BaseFrame {
	public Order() {
		super("order", 400, 400);
		
	}

	public static void main(String[] args) {
		new Order().setVisible(true);
	}
}
